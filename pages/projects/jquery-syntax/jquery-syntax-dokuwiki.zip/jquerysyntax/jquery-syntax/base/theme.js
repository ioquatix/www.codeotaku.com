Syntax.themes["base"] = []
