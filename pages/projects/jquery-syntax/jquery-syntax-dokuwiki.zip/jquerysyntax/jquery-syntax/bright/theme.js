Syntax.themes["bright"] = ["base"]
