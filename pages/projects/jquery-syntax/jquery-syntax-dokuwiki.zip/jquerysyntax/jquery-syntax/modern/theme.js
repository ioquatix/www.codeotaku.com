Syntax.themes["modern"] = ["base"]
